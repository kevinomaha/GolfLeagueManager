const axios = require('axios');

// Lambda handler function
exports.handler = async (event) => {
  console.log('Event received:', JSON.stringify(event));
  
  try {
    // Parse request path and parameters
    const path = event.path || '';
    const pathParams = event.pathParameters || {};
    const queryParams = event.queryStringParameters || {};
    
    // Extract the target URL from query parameters, falling back to path parameter
    let targetUrl = queryParams.url || pathParams.proxy || '';
    if (!targetUrl && path.startsWith('/proxy/')) {
      // Extract the URL from the path if it's in /proxy/{encoded_url} format
      targetUrl = decodeURIComponent(path.substring(7));
    }
    
    if (!targetUrl) {
      return {
        statusCode: 400,
        headers: corsHeaders(),
        body: JSON.stringify({ error: 'Target URL is required' }),
      };
    }
    
    // Setup request options
    const method = event.httpMethod || 'GET';
    const headers = {};
    
    // Forward selected headers from the original request
    const incomingHeaders = event.headers || {};
    const forwardHeaders = [
      'accept',
      'content-type',
      'authorization',
      'x-api-key'
    ];
    
    forwardHeaders.forEach(header => {
      if (incomingHeaders[header]) {
        headers[header] = incomingHeaders[header];
      }
    });
    
    // Add the original origin as referer
    if (incomingHeaders.origin) {
      headers['referer'] = incomingHeaders.origin;
    }
    
    // Parse and prepare request body if present
    let requestBody = event.body;
    if (requestBody && event.isBase64Encoded) {
      requestBody = Buffer.from(requestBody, 'base64').toString();
    }
    
    // Make the actual request to the target API
    console.log(`Proxying ${method} request to ${targetUrl}`);
    const response = await axios({
      method,
      url: targetUrl,
      headers,
      data: requestBody ? JSON.parse(requestBody) : undefined,
      validateStatus: () => true, // Don't throw on any status
    });
    
    // Prepare the Lambda response
    const lambdaResponse = {
      statusCode: response.status,
      headers: {
        ...corsHeaders(incomingHeaders.origin),
        ...normalizeHeaders(response.headers),
      },
      body: typeof response.data === 'object' 
        ? JSON.stringify(response.data)
        : response.data,
    };
    
    return lambdaResponse;
  } catch (error) {
    console.error('Proxy error:', error);
    
    return {
      statusCode: 500,
      headers: corsHeaders(),
      body: JSON.stringify({
        error: 'Proxy request failed',
        message: error.message,
      }),
    };
  }
};

// Helper function to create CORS headers
function corsHeaders(origin = '*') {
  return {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS,PATCH',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,X-Requested-With',
    'Access-Control-Allow-Credentials': 'true'
  };
}

// Helper function to normalize response headers
function normalizeHeaders(headers) {
  const normalizedHeaders = {};
  const headersToOmit = [
    'connection',
    'keep-alive',
    'transfer-encoding',
    'content-length',
    'access-control-allow-origin',
    'access-control-allow-methods',
    'access-control-allow-headers',
    'access-control-allow-credentials'
  ];

  // Convert headers to lowercase for case-insensitive comparison
  const headerNames = Object.keys(headers || {});
  
  headerNames.forEach(name => {
    const lowerName = name.toLowerCase();
    if (!headersToOmit.includes(lowerName)) {
      normalizedHeaders[name] = headers[name];
    }
  });
  
  return normalizedHeaders;
}
